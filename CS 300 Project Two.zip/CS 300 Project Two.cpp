// CS 300 Project Two.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

// Define a structure for Course
struct Course {
    string courseNumber;
    string courseTitle;
    vector<string> prerequisites;
};

// Function prototypes
void loadDataStructure(vector<Course>& courses, const string& filename);
void printCourseList(const vector<Course>& courses);
void printCourse(const vector<Course>& courses);
void displayMenu();

int main() {
    vector<Course> courses;
    string filename;
    char choice;

    do {
        displayMenu();
        cin >> choice;

        switch (choice) {
        case '1':
            cout << "Enter filename: ";
            cin >> filename;
            loadDataStructure(courses, filename);
            break;
        case '2':
            printCourseList(courses);
            break;
        case '3':
            printCourse(courses);
            break;
        case '4':
            cout << "Exiting program...\n";
            break;
        default:
            cout << "Invalid choice. Please try again.\n";
            break;
        }
    } while (choice != '4');

    return 0;
}

// Function to load data from file into data structure
void loadDataStructure(vector<Course>& courses, const string& filename) {
    ifstream file(filename);
    if (!file.is_open()) {
        cout << "Error opening file.\n";
        return;
    }

    // Read data from file and populate courses vector
    Course course;
    while (file >> course.courseNumber >> course.courseTitle) {
        string prerequisite;
        while (file >> prerequisite && prerequisite != "END") {
            course.prerequisites.push_back(prerequisite);
        }
        courses.push_back(course);
    }

    file.close();
    cout << "Data loaded successfully.\n";
}

// Function to print a list of courses in alphanumeric order
void printCourseList(const vector<Course>& courses) {
    vector<Course> csCourses; // Filtered Computer Science courses
    for (const auto& course : courses) {
        // Check if the courseNumber starts with "CS" or "MATH"
        if (course.courseNumber.substr(0, 2) == "CS" || course.courseNumber.substr(0, 4) == "MATH") {
            csCourses.push_back(course);
        }
    }

    // Sort the courses alphabetically by courseNumber
    sort(csCourses.begin(), csCourses.end(), [](const Course& a, const Course& b) {
        return a.courseNumber < b.courseNumber;
        });

    // Print the sorted list
    for (const auto& course : csCourses) {
        cout << course.courseNumber << " - " << course.courseTitle << endl;
    }
}

// Function to print information about a specific course
void printCourse(const vector<Course>& courses) {
    string courseNumber;
    cout << "Enter course number: ";
    cin >> courseNumber;

    // Find the course with the given courseNumber
    auto it = find_if(courses.begin(), courses.end(), [&](const Course& course) {
        return course.courseNumber == courseNumber;
        });

    if (it != courses.end()) {
        // Print course information
        cout << "Course Title: " << it->courseTitle << endl;
        cout << "Prerequisites: ";
        for (const auto& prerequisite : it->prerequisites) {
            cout << prerequisite << " ";
        }
        cout << endl;
    }
    else {
        cout << "Course not found.\n";
    }
}

// Function to display the menu
void displayMenu() {
    cout << "\nMenu:\n";
    cout << "1. Load Data Structure\n";
    cout << "2. Print Course List\n";
    cout << "3. Print Course Information\n";
    cout << "4. Exit\n";
    cout << "Enter your choice: ";
}